#pragma once
#include "headers/Pokemon.h"
#include <SFML/Graphics.hpp>
#include <iostream>
#include <string>
#include "Combat.h"

class Combat
{
	sf::Font font;
	Pokemon poke1;
	Pokemon poke2;

	std::string Attacking_poke;
	int Poke1_hp;
	int Poke2_hp;

	sf::Text text;
	bool spaceIsPressed;
	
public:
	Combat(Pokemon &poke1, Pokemon &poke2);
	void Turn();
	void Texte(int, int);
	void Texte(int, int, std::string);
	void ChoseCapacity();
};

