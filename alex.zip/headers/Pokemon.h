#pragma once
#include <string>
#include <SFML/Graphics.hpp>
#include "Capacities.h"

struct stats
{
	std::string name;
	int health;
	int level;
	int exp;
	int def;
	int atk;
	int speDef;
	int speAtk;
	int speed;
	int tempDefBoost = 0;
	int tempAtkBoost = 0;
	int tempSpeDefBoost = 0;
	int tempSpeAtkBoost = 0;
	int tempSpeedBoost = 0;
	int tempPrecisionDeBuff = 0;
	std::string type1;
	std::string type2;
	std::string status;
	capacity chosenCapacity;
};

struct capacities
{
	struct capacity lutte;
	struct capacity capacity1;
	struct capacity capacity2;
	struct capacity capacity3;
	struct capacity capacity4;
};

class Pokemon
{
	sf::Sprite sprite;
	struct capacities capacity;
	struct capacities capacity2[4];
	struct stats stat;
public:
	Pokemon	(std::string name, int health, int level, int exp, int def, int atk, int speDef, int speAtk, int speed, struct capacity capacity1, struct capacity capacity2, struct capacity capacity3, struct capacity capacity4, std::string type1, std::string type2 = "None", std::string status = "None");
	capacities &getCapacities();
	stats &getStats();
	sf::Sprite getSprite();
};

