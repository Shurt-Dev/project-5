#pragma once
#include <iostream>
#include <SFML/Graphics.hpp>

class App
{
	int windowWidth;
	int windowHeight;
	sf::RenderWindow window;
	sf::Clock clock;
public:
	App();
	sf::RenderWindow* GetWindow();
	sf::Clock GetClock();
	int mainApp();
	bool AppEvent();
};

