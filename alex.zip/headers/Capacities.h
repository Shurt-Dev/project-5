#pragma once
#include <string>

const struct capacity
{
	std::string capacityName;
	std::string capacityType;
	std::string category;
	int useTotal;
	int useLeft;
	int power;
	int defBoost;
	int atkBoost;
	int speDefBoost;
	int speAtkBoost;
	int speedBoost;
	int defDeBuff;
	int atkDeBuff;
	int speDefDeBuff;
	int speAtkDeBuff;
	int speedDeBuff;
	int healthBoost;
	int precision;
	int precisionDeBuff;
	std::string appliedStatus;
	int appliedStatusChance;
	int CritChance;
};

class Capacities
{
public:
	Capacities();

	static const double boostAndDebuffs[13];

	static capacity Charge();

	static capacity Eclair();

	static capacity Mimi_Queue();

	static capacity Rugissement();

	static capacity Implore();

	static capacity Pistolet_a_O();

	static capacity Flammeche();

	static capacity Choc_Mental();

	static capacity Jet_de_Sable();

	static capacity Morsure();

	static capacity Tranche_Herbe();

	static capacity Vent_Glace();

	static capacity Vent_Feerique();
};