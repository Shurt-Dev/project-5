#include "../headers/Pokemon.h"
#include "../headers/Capacities.h"

Pokemon::Pokemon(std::string name, int health, int level, int exp, int def, int atk, int speDef, int speAtk, int speed, struct capacity capacity1, struct capacity capacity2, struct capacity capacity3, struct capacity capacity4, std::string type1, std::string type2, std::string status)
{
    getStats().name = name;
    getStats().health = health;
    getStats().level = level;
    getStats().exp = exp;
    getStats().def = def;
    getStats().atk = atk;
    getStats().speDef = speDef;
    getStats().speAtk = speAtk;
    getStats().speed = speed;
    getStats().type1 = type1;
    getStats().type2 = type2;
    getStats().status = status;
    getCapacities().capacity1 = capacity1;
    getCapacities().capacity2 = capacity2;
    getCapacities().capacity3 = capacity3;
    getCapacities().capacity4 = capacity4;
};

capacities &Pokemon::getCapacities()
{
    return this->capacity;
}

stats &Pokemon::getStats()
{
    return this->stat;
}

sf::Sprite Pokemon::getSprite()
{
    return this->sprite;
}
