#include <SFML/Graphics.hpp>
#include <iostream>
#include "../headers/App.h"
#include "../headers/Character.h"
#include "../headers/Pokemon.h"

int windowWidth;
int windowHeight;

int main()
{
    srand(time(nullptr));
    App Window;
    Window.mainApp();
    
    return 0;
}