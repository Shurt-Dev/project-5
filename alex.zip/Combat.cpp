#include <string>
#include "Combat.h"
#include "headers/Pokemon.h"

Combat::Combat(Pokemon &poke1, Pokemon &poke2)
{
	this->poke1 = poke1;
	this->poke2 = poke2;

	if (!this->font.loadFromFile("font/SourceSansPro-SemiBold.ttf")) {
		std::cout << "Error while loading font" << std::endl;
	}

	sf::Texture fond;
	if (!fond.loadFromFile("images/fond_combat.png")) {
		std::cout << "Error while loading image" << std::endl;
	};
	sf::Sprite Fond;
	Fond.setTexture(fond);

	sf::Text text;
	text.setFont(font);
	text.setFillColor(sf::Color(0, 0, 0));
	text.setCharacterSize(30);

	bool spaceIsPressed = 0;
}

void Combat::Turn()
{
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
	{
		this->spaceIsPressed = 1;
	}
	if (spaceIsPressed)
	{
		if ( poke1.getStats().health > 0 && poke2.getStats().health > 0)
		{
			if (poke1.getStats().speed < poke2.getStats().speed)
			{
				poke1.getStats().health = poke1.getStats().health - ((((poke2.getStats().level * 0.4 + 2) * Poke2_atk/* *power*/) / (Poke1_def * 50) + 2)/* *CM*/);
				Attacking_poke = poke2.getStats().name + " attacks first ";
				if (poke1.getStats().health > 0)
				{
					poke2.getStats().health = poke2.getStats().health - ((((poke1.getStats().level * 0.4 + 2) * Poke1_atk/* *power*/) / (Poke2_def * 50) + 2)/* *CM*/);
				}
			}
			else if (poke1.getStats().speed > poke2.getStats().speed)
			{
				poke2.getStats().health = poke2.getStats().health - ((((poke1.getStats().level * 0.4 + 2) * Poke1_atk/* *power*/) / (Poke2_def * 50) + 2)/* *CM*/);
				Attacking_poke = poke1.getStats().name + " attacks first ";
				if (poke2.getStats().health > 0)
				{
					poke1.getStats().health = poke1.getStats().health - ((((poke2.getStats().level * 0.4 + 2) * Poke2_atk/* *power*/) / (Poke1_def * 50) + 2)/* *CM*/);
				}
			}
			else
			{
				int poketurn = rand() % 2;
				if (poketurn == 0)
				{
					poke1.getStats().health = poke1.getStats().health - ((((poke2.getStats().level * 0.4 + 2) * Poke2_atk/* *power*/) / (Poke1_def * 50) + 2)/* *CM*/);
					Attacking_poke = poke2.getStats().name + " attacks first ";
					if (poke1.getStats().health > 0)
					{
						poke2.getStats().health = poke2.getStats().health - ((((poke1.getStats().level * 0.4 + 2) * Poke1_atk/* *power*/) / (Poke2_def * 50) + 2)/* *CM*/);
					}
				}
				else if (poketurn == 1)
				{
					poke2.getStats().health = poke2.getStats().health - ((((poke1.getStats().level * 0.4 + 2) * Poke1_atk/* *power*/) / (Poke2_def * 50) + 2)/* *CM*/);
					Attacking_poke = poke1.getStats().name + " attacks first ";
					if (poke2.getStats().health > 0)
					{
						poke1.getStats().health = poke1.getStats().health - ((((poke2.getStats().level * 0.4 + 2) * Poke2_atk/* *power*/) / (Poke1_def * 50) + 2)/* *CM*/);
					}
				}
			}
			PokeAttack.setString(Attacking_poke);
			Texte(30, 625);
		}
	}
	sf::Texture fond;
	if (!fond.loadFromFile("images/fond_combat.png")) {
		std::cout << "Error while loading image" << std::endl;
	};

	sf::Sprite Fond;
	Fond.setTexture(fond);

	if (poke1.getStats().health <= 0 && poke2.getStats().health > 0) {
		text.setString(poke1.getStats().name + " : " + std::to_string(poke1.getStats().health) + " HP\n" + poke2.getStats().name + " : " + std::to_string(poke2.getStats().health) + " HP\n" + poke2.getStats().name + " won the fight.");
	}
	else if (poke2.getStats().health <= 0 && poke1.getStats().health > 0) {
		text.setString(poke1.getStats().name + " : " + std::to_string(poke1.getStats().health) + " HP\n" + poke2.getStats().name + " : " + std::to_string(poke2.getStats().health) + " HP\n" + poke1.getStats().name + " won the fight.");
	}

	window.clear();
	window.draw(Fond);
	window.draw(text);
	//window.draw(PokeAttack);
	//window.draw(PokeWinner);
	window.draw(poke1.getSprite());
	window.draw(poke2.getSprite());
	window.display();
}

void Combat::Texte(int x, int y)
{
	this->text.setPosition(x, y);
	this->text.setString(poke1.getStats().name + " : " + std::to_string(poke1.getStats().health) + " HP\n" + poke2.getStats().name + " : " + std::to_string(poke2.getStats().health) + " HP\n");
}

void Combat::Texte(int x, int y, std::string text)
{
	this->text.setPosition(x, y);
	this->text.setString(text);
}

void Combat::ChoseCapacity(Pokemon poke)
{
	int chosenCapacity;
	this->text.setPosition(30, 625);
	this->text.setString("Choose the capacity to use:\n" + "1." + poke.getCapacities().capacity1.capacityName + "                  " + "2." + poke.getCapacities().capacity2.capacityName + "\n" + "3." + poke.getCapacities().capacity3.capacityName + "                  " + "4." + poke.getCapacities().capacity4.capacityName);
	std::cin >> chosenCapacity;
	switch (chosenCapacity) 
	{
	case 1:

	case 2:

	case 3:
		
	case 4:

	}
}
